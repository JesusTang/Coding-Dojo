console.log("page loaded...");
function playVideo(element) {
    element.play();
}

function pauseVideo(element) {
    element.pause();
}