function changeToLOGOUT(element) {
    element.innerHTML = "Logout"
}
function hide(element) {
    element.remove()
}